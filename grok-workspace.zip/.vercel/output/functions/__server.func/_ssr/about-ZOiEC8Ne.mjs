import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as school, s as useI18n } from "./school-D7B0jihh.mjs";
import { n as PageHead } from "./router-BKV5VRyZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-ZOiEC8Ne.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	const { t } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: t.kicker,
			title: t.about.title,
			lead: t.about.lead
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 pb-16 sm:px-6 md:grid-cols-2",
			children: t.about.cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg border border-border bg-bg-elevated p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: card.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-fg-muted",
					children: card.body
				})]
			}, card.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "mx-auto max-w-6xl px-4 pb-8 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md border border-border bg-bg-elevated px-5 py-4 text-sm text-fg-muted",
				children: t.about.note
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs text-fg-subtle",
				children: [
					"OSM ",
					school.osmWay,
					" · ",
					school.plusCode,
					" · ",
					school.coords.lat,
					", ",
					school.coords.lon
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-6xl px-4 pb-16 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/facade.jpg",
				alt: "",
				className: "aspect-[21/9] w-full rounded-xl object-cover"
			})
		})
	] });
}
//#endregion
export { AboutPage as component };
