import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as useI18n } from "./school-D7B0jihh.mjs";
import { n as PageHead } from "./router-BKV5VRyZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/education-Bt7_MBXX.js
var import_jsx_runtime = require_jsx_runtime();
function EducationPage() {
	const { t } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: t.kicker,
			title: t.education.title,
			lead: t.education.lead
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 sm:px-6 md:grid-cols-3",
			children: t.education.blocks.map((block) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg border border-border bg-bg-elevated p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: block.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-fg-muted",
					children: block.body
				})]
			}, block.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-10 grid max-w-6xl gap-6 px-4 pb-16 sm:px-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-bg-ink p-6 text-fg-on-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: t.education.langTitle
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-fg-on-ink/75",
					children: t.education.langBody
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-border bg-bg-elevated p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: t.education.hoursTitle
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-fg-muted",
					children: t.education.hoursBody
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-6xl px-4 pb-16 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/classroom.jpg",
				alt: "",
				className: "aspect-[16/8] w-full rounded-xl object-cover"
			})
		})
	] });
}
//#endregion
export { EducationPage as component };
