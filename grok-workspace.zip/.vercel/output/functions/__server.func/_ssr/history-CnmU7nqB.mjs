import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as useI18n } from "./school-D7B0jihh.mjs";
import { n as PageHead } from "./router-BKV5VRyZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/history-CnmU7nqB.js
var import_jsx_runtime = require_jsx_runtime();
function HistoryPage() {
	const { t } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: t.kicker,
			title: t.history.title,
			lead: t.history.lead
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-4 pb-8 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/hero.jpg",
				alt: "",
				className: "aspect-[4/5] w-full rounded-xl object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-8",
				children: t.history.timeline.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-2 border-l border-border pl-5 sm:grid-cols-[7rem_1fr] sm:border-0 sm:pl-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs uppercase tracking-[0.16em] text-sage",
						children: item.year
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-fg-muted",
						children: item.body
					})] })]
				}, item.year))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto max-w-6xl px-4 pb-16 text-sm text-fg-muted sm:px-6",
			children: t.history.archNote
		})
	] });
}
//#endregion
export { HistoryPage as component };
