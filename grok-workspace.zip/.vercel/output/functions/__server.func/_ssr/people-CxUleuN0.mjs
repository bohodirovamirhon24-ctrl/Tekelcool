import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as school, o as teachers, s as useI18n } from "./school-D7B0jihh.mjs";
import { n as PageHead } from "./router-BKV5VRyZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/people-CxUleuN0.js
var import_jsx_runtime = require_jsx_runtime();
function PeoplePage() {
	const { t, lang } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: t.kicker,
			title: t.people.title,
			lead: t.people.lead
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-3xl px-4 pb-6 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md border border-border bg-bg-elevated px-5 py-4 text-sm text-fg-muted",
				children: t.people.disclaimer
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mx-auto max-w-3xl divide-y divide-border border-y border-border",
			children: teachers.map((teacher) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-baseline justify-between gap-4 px-4 py-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl",
					children: lang === "ru" ? teacher.nameRu : lang === "uz" ? teacher.nameUz : teacher.name
				}), "note" in teacher && teacher.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs uppercase tracking-[0.14em] text-fg-muted",
					children: teacher.note
				}) : null]
			}, teacher.nameRu))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto max-w-3xl px-4 py-10 text-sm text-fg-muted sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: school.youtubeSearch,
				className: "underline-offset-4 hover:underline",
				children: t.people.source
			})
		})
	] });
}
//#endregion
export { PeoplePage as component };
