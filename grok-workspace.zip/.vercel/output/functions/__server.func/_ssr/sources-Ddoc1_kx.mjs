import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as sources, s as useI18n } from "./school-D7B0jihh.mjs";
import { n as PageHead } from "./router-BKV5VRyZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sources-Ddoc1_kx.js
var import_jsx_runtime = require_jsx_runtime();
function SourcesPage() {
	const { t } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: t.kicker,
			title: t.sources.title,
			lead: t.sources.lead
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto max-w-3xl px-4 pb-8 text-sm sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/SCHOOL-194.md",
				className: "underline-offset-4 hover:underline",
				download: true,
				children: "SCHOOL-194.md"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mx-auto max-w-3xl space-y-6 px-4 pb-16 sm:px-6",
			children: sources.map((source, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-t border-border pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-fg-muted",
						children: String(index + 1).padStart(2, "0")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: source.url,
						className: "mt-1 block font-display text-2xl no-underline hover:underline",
						target: "_blank",
						rel: "noreferrer",
						children: source.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-fg-muted",
						children: source.about
					})
				]
			}, source.url))
		})
	] });
}
//#endregion
export { SourcesPage as component };
