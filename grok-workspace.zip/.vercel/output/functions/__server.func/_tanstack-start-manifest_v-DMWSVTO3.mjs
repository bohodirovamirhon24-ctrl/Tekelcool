//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DMWSVTO3.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contacts",
			"/education",
			"/history",
			"/people",
			"/sources"
		],
		preloads: ["/assets/index-BoQwRjpC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BoQwRjpC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BnF-XCb9.js", "/assets/button-D6R3KsdK.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-vXHSHg_F.js"]
	},
	"/contacts": {
		filePath: "/workspace/src/routes/contacts.tsx",
		children: void 0,
		preloads: ["/assets/contacts-YTUNroIA.js", "/assets/button-D6R3KsdK.js"]
	},
	"/education": {
		filePath: "/workspace/src/routes/education.tsx",
		children: void 0,
		preloads: ["/assets/education-CAikZLDc.js"]
	},
	"/history": {
		filePath: "/workspace/src/routes/history.tsx",
		children: void 0,
		preloads: ["/assets/history-CkR4KqYw.js"]
	},
	"/people": {
		filePath: "/workspace/src/routes/people.tsx",
		children: void 0,
		preloads: ["/assets/people-b2Smsvwl.js"]
	},
	"/sources": {
		filePath: "/workspace/src/routes/sources.tsx",
		children: void 0,
		preloads: ["/assets/sources-DyVevMaX.js"]
	}
} });
//#endregion
export { tsrStartManifest };
