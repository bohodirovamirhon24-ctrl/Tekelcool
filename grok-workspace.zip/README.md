# 194-maktab · Toshkent

Official-style public site for **Umumiy o‘rta ta’lim maktabi №194**  
(Общеобразовательная средняя школа №194), Uchtepa district, Chilanzar-25, Tashkent.

Phone: **+998 71 272-08-05**  
Address: Uzbekistan, 100152, Tashkent, Uchtepa, Chilanzar-25, 16a  
Instruction: Russian  
Hours: Mon–Sat 08:00–18:00

## Stack

- React 19 + TanStack Start / Router
- Tailwind CSS v4
- TypeScript

## Run locally

```bash
npm install
npm run dev
```

Open the printed local URL. Default language is Russian; switch UZ / RU / EN in the header.

```bash
npm run build
npm run typecheck
```

## What is verified vs not invented

Open directories, OpenStreetMap, 2GIS, Golden Pages, Yellow Pages, and archive articles on mytashkent.uz.

**Not published in open sources (so this site does not invent them):** director name, current staff roster, pupil count.

Teacher names on `/people` come from alumni comments on a 2022 YouTube video and are labelled as memory, not a current roster.

## Licence

Facts belong to their original publishers. Code in this repository may be reused for the school.
