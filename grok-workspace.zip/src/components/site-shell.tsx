import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState, type ReactNode } from "react";
import { LANGS } from "@/lib/copy";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/cn";
import { school } from "@/lib/school";

const links = [
  { to: "/", key: "home" as const },
  { to: "/about", key: "about" as const },
  { to: "/history", key: "history" as const },
  { to: "/education", key: "education" as const },
  { to: "/people", key: "people" as const },
  { to: "/contacts", key: "contacts" as const },
];

export function SiteShell({ children }: { children: ReactNode }) {
  const { t, lang, setLang } = useI18n();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const mark = lang === "en" ? "school" : lang === "ru" ? "школа" : "maktab";

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-bg-elevated focus:px-3 focus:py-2"
      >
        Skip
      </a>
      <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <Link to="/" className="flex items-baseline gap-2 no-underline">
            <span className="font-display text-2xl font-medium tracking-tight">194</span>
            <span className="text-xs uppercase tracking-[0.18em] text-fg-muted">{mark}</span>
          </Link>

          <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
            {links.map((item) => {
              const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "rounded-sm px-3 py-2 text-sm text-fg-muted no-underline transition-colors duration-150 hover:text-fg",
                    active && "text-fg",
                  )}
                >
                  {t.nav[item.key]}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2">
            <div className="flex rounded-sm border border-border p-0.5" role="group" aria-label="Language">
              {LANGS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setLang(item.id)}
                  className={cn(
                    "min-h-8 rounded-[6px] px-2.5 text-xs font-medium text-fg-muted",
                    lang === item.id && "bg-bg-ink text-fg-on-ink",
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <button
              type="button"
              className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-sm border border-border lg:hidden"
              aria-label={open ? "Close" : "Menu"}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {open ? (
          <nav className="border-t border-border px-4 py-3 lg:hidden" aria-label="Mobile">
            <div className="flex flex-col">
              {links.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className="min-h-11 border-b border-border py-3 text-base no-underline last:border-0"
                >
                  {t.nav[item.key]}
                </Link>
              ))}
              <Link to="/sources" onClick={() => setOpen(false)} className="min-h-11 py-3 text-base no-underline">
                {t.nav.sources}
              </Link>
            </div>
          </nav>
        ) : null}
      </header>

      <main id="main">{children}</main>

      <footer className="mt-20 border-t border-border bg-bg-ink text-fg-on-ink">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-3">
          <div>
            <p className="font-display text-3xl">194</p>
            <p className="mt-2 max-w-xs text-sm text-fg-on-ink/70">{t.footer.line}</p>
          </div>
          <div className="text-sm text-fg-on-ink/75">
            <p>{t.contacts.address}</p>
            <a href={`tel:${school.phoneTel}`} className="mt-2 inline-block underline-offset-4 hover:underline">
              {school.phoneDisplay}
            </a>
          </div>
          <div className="text-sm">
            <Link to="/sources" className="underline-offset-4 hover:underline">
              {t.footer.sources}
            </Link>
            <p className="mt-3 max-w-sm text-fg-on-ink/60">{t.footer.note}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export function PageHead({
  kicker,
  title,
  lead,
}: {
  kicker: string;
  title: string;
  lead: string;
}) {
  return (
    <header className="mx-auto max-w-3xl px-4 pb-10 pt-14 sm:px-6">
      <p className="text-xs uppercase tracking-[0.22em] text-fg-muted">{kicker}</p>
      <h1 className="mt-3 text-4xl sm:text-5xl">{title}</h1>
      <p className="mt-4 text-lg text-fg-muted">{lead}</p>
    </header>
  );
}
