export type Lang = "uz" | "ru" | "en";

export const LANGS: { id: Lang; label: string }[] = [
  { id: "uz", label: "Oʻz" },
  { id: "ru", label: "Рус" },
  { id: "en", label: "Eng" },
];

export const copy = {
  uz: {
    siteName: "194-maktab",
    kicker: "Toshkent · Uchtepa tumani",
    nav: {
      home: "Bosh sahifa",
      about: "Maktab",
      history: "Tarix",
      education: "Taʼlim",
      people: "Ustozlar",
      contacts: "Aloqa",
      sources: "Manbalar",
    },
    hero: {
      eyebrow: "Umumiy oʻrta taʼlim maktabi",
      title: "194-sonli maktab",
      lead: "Chilonzor-25 mavzesidagi rus tilida taʼlim beradigan davlat maktabi. Binosi 1960-yillardagi Toshkent modernizmining namunasi.",
      cta: "Manzil va telefon",
      secondary: "Maktab tarixi",
    },
    facts: [
      { label: "Manzil", value: "Uchtepa, Chilonzor-25, 16a" },
      { label: "Telefon", value: "+998 71 272-08-05" },
      { label: "Ish vaqti", value: "Du–Sha 08:00–18:00" },
      { label: "Taʼlim tili", value: "Rus tili" },
    ],
    homeAbout: {
      kicker: "Bugun",
      title: "Uchtepa tumani, Chilonzor-25",
      body: "Maktab Toshkent shahar Uchtepa tumanida, Chilonzor-25 mavzesi, 16a-uyda joylashgan. Yuridik nomi — umumiy oʻrta taʼlim maktabi №194. Operator — Oʻzbekiston Respublikasi Maktabgacha va maktab taʼlimi vazirligi. Darslar rus tilida olib boriladi.",
      more: "Maktab haqida",
    },
    homeArch: {
      kicker: "Binolar",
      title: "1965-yilgi TasHNIEP loyihasi",
      body: "Hovlidan olingan 1967-yilgi surat saqlanib qolgan. Loyiha mualliflari: arxitektorlar B. P. Blyum, N. P. Zinkina, T. V. Lemina, muhandis L. E. Goritskiy. Shu turkumdagi maktablar Chilonzor va butun respublika boʻylab qurilgan.",
      more: "Arxitektura",
    },
    homePeople: {
      kicker: "Xotira",
      title: "Bitiruvchilar eslagan ustozlar",
      body: "Rasmiy shtat roʻyxati ochiq emas. 2022-yilgi maktab videosidagi izohlarda bitiruvchilar bir qator oʻqituvchilarni minnatdorchilik bilan tilga olishgan.",
      more: "Ismlar",
    },
    about: {
      title: "Maktab haqida",
      lead: "Davlat umumiy oʻrta taʼlim muassasasi. 1–11-sinflar. Rus tilida taʼlim.",
      cards: [
        {
          title: "Maʼmuriy maqom",
          body: "Yuridik nom: Общеобразовательная средняя школа №194 / UMUMIY OʻRTA TAʼLIM MAKTABI №194. Davlat muassasasi, Uchtepa tumani maktabgacha va maktab taʼlimi boʻlimi tizimida.",
        },
        {
          title: "Joylashuv",
          body: "Toshkent, 100152, Uchtepa tumani, Chilonzor-25 mavzesi, 16a. Moʻljal: Uchtepa eko-parki, 360-sonli bogʻcha, pochta boʻlimi №152. Koʻcha manzillarida Shibayeva nomi ham uchraydi.",
        },
        {
          title: "Bino",
          body: "Uch qavatli oʻquv korpusi. OpenStreetMap: 41.28226° N, 69.16654° E. Plus-kod: 8JHF75J8+WJ.",
        },
        {
          title: "Nom",
          body: "Rus tilidagi xaritalarda maktab «Школа №194 им. „Ленинграда“» deb yozilgan. Bu nom urush yillarida Toshkentga evakuatsiya qilingan leningradlik bolalar xotirasiga bogʻliq boʻlishi mumkin.",
        },
      ],
      note: "Oʻquvchilar soni, direktori va joriy shtat ochiq manbalarda tasdiqlanmagan — bu sahifada taxminlar keltirilmaydi.",
    },
    history: {
      title: "Tarix va arxitektura",
      lead: "Chilonzor massivi 1950–60-yillarda shakllangan. 194-maktab shu qurilish toʻlqinining bir qismi.",
      timeline: [
        {
          year: "1950–63",
          title: "Chilonzor tumanining paydo boʻlishi",
          body: "Koʻp qavatli uy-joy massivlari quriladi. 1963-yil 4-yanvarda Chilonzor tumani rasman tashkil etiladi. Keyinchalik 25-mavze Uchtepa tumaniga oʻtadi.",
        },
        {
          year: "1964–65",
          title: "Maktablar seriyasi 224-1-3S / 4S",
          body: "Arxitektor Boris Isaakovich Blyum (1931, Toshkent), N. P. Zinkina, T. V. Lemina (Lyamina) va muhandis L. E. Goritskiy 3–4 qavatli, 960–1000 va 1280–1320 oʻrinli maktablarning namunaviy loyihalarini yaratadilar. Blyum 1986-yilda SSSR Meʼmorlar uyushmasi diplomini olgan.",
        },
        {
          year: "1966",
          title: "Toshkent zilzilasi va qayta qurish",
          body: "1966-yilgi zilziladan soʻng poytaxt keng miqyosda qayta quriladi. Maktab binolari yangi mahallalarning majburiy qismi boʻladi.",
        },
        {
          year: "1967",
          title: "Hovlidan surat",
          body: "N. D. Koveshnikov 194-maktabni hovlidan suratga oladi. TasHNIEP 1965-yilgi loyiha. Shu reja boʻyicha 17, 5 va boshqa maktablar ham qurilgan.",
        },
        {
          year: "Bugun",
          title: "Uchtepa, Chilonzor-25",
          body: "Maktab faoliyatda. 3 qavat. Rus tilida taʼlim. Yaxta: 360-sonli bogʻcha, Uchtepa eko-parki, 287 va 78-maktablar.",
        },
      ],
      archNote:
        "Bu turkumdagi maktablarda oʻquv korpusi derazalar ritmi, yengil soyabonlar va hovli atrofida sport maydoni boʻladi. 107-maktab (Chilonzor-26) shu qatordagi toʻliq namunalardan biri hisoblanadi; boshqalari pastroq qavat va qisqaroq sport zali bilan qurilgan.",
    },
    education: {
      title: "Taʼlim",
      lead: "Umumiy oʻrta taʼlim: boshlangʻich, asosiy va oʻrta bosqichlar. Taʼlim tili — rus tili.",
      blocks: [
        {
          title: "1–4-sinflar",
          body: "Boshlangʻich taʼlim. Oʻzbekistonning milliy oʻquv dasturi asosida. Maktab rus tilida o‘qitadi — bu Golden Pages va tuman kataloglarida alohida belgilangan.",
        },
        {
          title: "5–9-sinflar",
          body: "Asosiy oʻrta taʼlim. Davlat taʼlim standarti, attestatsiya va keyingi yoʻnalish tanlovi.",
        },
        {
          title: "10–11-sinflar",
          body: "Oʻrta taʼlim. Bitiruvchilar OTMga kirish, kasb-hunar va harbiy xizmat yoʻnalishlariga chiqadi.",
        },
      ],
      langTitle: "Nega rus tili muhim",
      langBody:
        "Uchtepa tumanida oʻzbek va rus tillarida ishlaydigan maktablar yonma-yon turadi. 194-maktab rus tilidagi taʼlim markazlaridan biri. Bu oilalarga tanlov beradi: yaqin 193-maktab, masalan, oʻzbek tilida belgilangan.",
      hoursTitle: "Ish tartibi",
      hoursBody:
        "Kataloglar: dushanba–shanba 08:00–18:00, tushliksiz; yakshanba — dam olish. Ayrim xarita xizmatlari 08:30 ni koʻrsatadi. Aniq dars jadvali maktab maʼmuriyatidan olinadi.",
    },
    people: {
      title: "Ustozlar",
      lead: "Quyidagi ismlar 2022-yil 8-mart videosidagi bitiruvchilar izohlaridan. Bu joriy shtat emas — xotira.",
      disclaimer:
        "Ochiq manbalarda direktori va toʻliq pedagogik jamoa eʼlon qilinmagan. Agar ism notoʻgʻri yozilgan boʻlsa, tuzatish uchun murojaat qiling.",
      source: "Manba: YouTube, kanal «ШКОЛА-194 УЧТЕПА ГОРОД ТАШКЕНТ»",
    },
    contacts: {
      title: "Aloqa",
      lead: "Telefon orqali bogʻlaning. Qabul kunlari ochiq manbalarda yoʻq.",
      addressLabel: "Manzil",
      address: "Oʻzbekiston, 100152, Toshkent, Uchtepa tumani, Chilonzor-25 mavzesi, 16a",
      phoneLabel: "Telefon",
      hoursLabel: "Ish vaqti",
      hours: "Dushanba–shanba: 08:00–18:00. Yakshanba: dam olish.",
      transitLabel: "Transport (maʼlumotnoma)",
      transit: "Avtobus 2, 8, 41, 77; marshrut 14, 15, 21 — Top.uz maʼlumotnomasi. Marshrutlar oʻzgarishi mumkin.",
      nearbyLabel: "Moʻljal",
      nearby:
        "360-sonli bogʻcha (≈130 m), Nur Saroy banket zali, Uchtepa eko-parki, pochta №152, 287-maktab.",
      mapLabel: "Xarita",
      call: "Qoʻngʻiroq qilish",
      osm: "OpenStreetMap",
      gmaps: "Google Maps",
      formTitle: "Eslatma qoldirish",
      formLead:
        "Xabar maktabga yuborilmaydi — brauzeringizda saqlanadi. Rasmiy savol uchun telefon.",
      formName: "Ism",
      formText: "Xabar",
      formSubmit: "Saqlash",
      formEmpty: "Hali xabar yoʻq.",
    },
    sources: {
      title: "Manbalar",
      lead: "Sahifa ochiq katalog, xarita va arxiv maqolalariga tayanadi. Nomaʼlum faktlar uydirilmagan.",
    },
    footer: {
      line: "194-sonli umumiy oʻrta taʼlim maktabi · Toshkent, Uchtepa",
      sources: "Manbalar va kod",
      note: "Maʼlumotlar ochiq manbalardan. Joriy shtat va oʻquvchilar soni tasdiqlanmagan.",
    },
  },
  ru: {
    siteName: "Школа 194",
    kicker: "Ташкент · Учтепинский район",
    nav: {
      home: "Главная",
      about: "Школа",
      history: "История",
      education: "Учёба",
      people: "Учителя",
      contacts: "Контакты",
      sources: "Источники",
    },
    hero: {
      eyebrow: "Общеобразовательная средняя школа",
      title: "Школа №194",
      lead: "Государственная школа с русским языком обучения в массиве Чиланзар-25. Здание — образец ташкентского модернизма 1960-х.",
      cta: "Адрес и телефон",
      secondary: "История школы",
    },
    facts: [
      { label: "Адрес", value: "Учтепа, Чиланзар-25, 16а" },
      { label: "Телефон", value: "+998 71 272-08-05" },
      { label: "Часы", value: "Пн–Сб 08:00–18:00" },
      { label: "Язык", value: "Русский" },
    ],
    homeAbout: {
      kicker: "Сегодня",
      title: "Учтепинский район, Чиланзар-25",
      body: "Школа находится в Ташкенте, Учтепинский район, массив Чиланзар-25, дом 16а. Юридическое название — общеобразовательная средняя школа №194. Оператор — Министерство дошкольного и школьного образования. Обучение ведётся на русском языке.",
      more: "О школе",
    },
    homeArch: {
      kicker: "Здание",
      title: "Проект ТашНИИЭП 1965 года",
      body: "Сохранилась фотография двора 1967 года. Авторы: архитекторы Б. П. Блюм, Н. П. Зинкина, Т. В. Лемина, инженер Л. Е. Горицкий. По этой серии строили школы по всему Чиланзару и республике.",
      more: "Архитектура",
    },
    homePeople: {
      kicker: "Память",
      title: "Учителя, которых помнят выпускники",
      body: "Официальный штат в открытом доступе не опубликован. В комментариях к школьному видео 2022 года выпускники благодарят конкретных педагогов.",
      more: "Имена",
    },
    about: {
      title: "О школе",
      lead: "Государственное учреждение общего среднего образования. 1–11 классы. Русский язык обучения.",
      cards: [
        {
          title: "Статус",
          body: "Юридическое имя: Общеобразовательная средняя школа №194. Государственное учреждение в системе отдела дошкольного и школьного образования Учтепинского района.",
        },
        {
          title: "Место",
          body: "Ташкент, 100152, Учтепинский район, массив Чиланзар-25, 16а. Ориентиры: экопарк Учтепа, детский сад №360, почтовое отделение №152. В справочниках встречается улица Шибаева.",
        },
        {
          title: "Здание",
          body: "Три этажа. OpenStreetMap: 41.28226° с. ш., 69.16654° в. д. Plus-код: 8JHF75J8+WJ.",
        },
        {
          title: "Имя",
          body: "На русскоязычных картах школа значится как «Школа №194 им. „Ленинграда“». Название, скорее всего, связано с эвакуацией ленинградских детей в Ташкент в годы войны.",
        },
      ],
      note: "Численность учеников, директор и актуальный штат в открытых источниках не подтверждены — на сайте нет выдуманных цифр.",
    },
    history: {
      title: "История и архитектура",
      lead: "Массив Чиланзар сложился в 1950–60-е. Школа 194 — часть этой застройки.",
      timeline: [
        {
          year: "1950–63",
          title: "Рождение Чиланзара",
          body: "Строятся многоэтажные кварталы. 4 января 1963 года район Чиланзар оформлен официально. Позже 25-й квартал вошёл в Учтепинский район.",
        },
        {
          year: "1964–65",
          title: "Серия школ 224-1-3С / 4С",
          body: "Архитектор Борис Исаакович Блюм (род. 25 августа 1931, Ташкент), Н. П. Зинкина, Т. В. Лемина и инженер Л. Е. Горицкий проектируют 3–4-этажные школы на 960–1000 и 1280–1320 мест. В 1986 году Блюм получает диплом Союза архитекторов СССР.",
        },
        {
          year: "1966",
          title: "Землетрясение и новая столица",
          body: "После землетрясения 1966 года Ташкент отстраивают заново. Школы становятся обязательной частью микрорайонов.",
        },
        {
          year: "1967",
          title: "Снимок со двора",
          body: "Н. Д. Ковешников фотографирует школу 194 со двора. Проект ТашНИИЭП 1965 года. По этому плану построены школы 17, 5 и другие.",
        },
        {
          year: "Сейчас",
          title: "Учтепа, Чиланзар-25",
          body: "Школа работает. Три этажа. Русский язык обучения. Рядом сад №360, экопарк Учтепа, школы 287 и 78.",
        },
      ],
      archNote:
        "У серии ритмичный учебный корпус, солнцезащита на окнах и двор со спортплощадкой. Школа 107 на 26-м квартале Чиланзара — полный образец; остальные часто ниже и с укороченным залом.",
    },
    education: {
      title: "Учёба",
      lead: "Общее среднее образование: начальная, основная и старшая школа. Язык обучения — русский.",
      blocks: [
        {
          title: "1–4 классы",
          body: "Начальная школа по национальной программе Узбекистана. Русский язык обучения отдельно отмечен в Golden Pages и районных каталогах.",
        },
        {
          title: "5–9 классы",
          body: "Основное среднее образование, государственная аттестация и выбор дальнейшего пути.",
        },
        {
          title: "10–11 классы",
          body: "Полное среднее образование. Выпускники идут в вузы, колледжи и на службу.",
        },
      ],
      langTitle: "Русский сектор",
      langBody:
        "В Учтепе рядом работают школы с узбекским и русским языком. 194-я — одна из русских. Рядом, например, школа 193 указана как узбекская — у семей есть выбор в квартале.",
      hoursTitle: "Режим",
      hoursBody:
        "Справочники: понедельник–суббота 08:00–18:00 без обеденного перерыва; воскресенье — выходной. Отдельные карты показывают 08:30. Точное расписание уроков — у администрации.",
    },
    people: {
      title: "Учителя",
      lead: "Имена из комментариев выпускников к видео 8 марта 2022 года. Это не актуальный штат — это память.",
      disclaimer:
        "Директор и полный состав педагогов в открытых источниках не опубликованы. Если имя записано неверно — напишите, исправим.",
      source: "Источник: YouTube, канал «ШКОЛА-194 УЧТЕПА ГОРОД ТАШКЕНТ»",
    },
    contacts: {
      title: "Контакты",
      lead: "Звоните по телефону. Дни приёма в открытых источниках не указаны.",
      addressLabel: "Адрес",
      address: "Узбекистан, 100152, Ташкент, Учтепинский район, массив Чиланзар-25, 16а",
      phoneLabel: "Телефон",
      hoursLabel: "Часы работы",
      hours: "Понедельник–суббота: 08:00–18:00. Воскресенье: выходной.",
      transitLabel: "Транспорт (справочно)",
      transit: "Автобусы 2, 8, 41, 77; маршрутки 14, 15, 21 — по данным Top.uz. Маршруты могли измениться.",
      nearbyLabel: "Ориентиры",
      nearby: "Детский сад №360 (≈130 м), банкетный зал Nur Saroy, экопарк Учтепа, почта №152, школа 287.",
      mapLabel: "Карта",
      call: "Позвонить",
      osm: "OpenStreetMap",
      gmaps: "Google Maps",
      formTitle: "Оставить заметку",
      formLead: "Сообщение не уходит в школу — хранится в браузере. По делу звоните.",
      formName: "Имя",
      formText: "Текст",
      formSubmit: "Сохранить",
      formEmpty: "Пока пусто.",
    },
    sources: {
      title: "Источники",
      lead: "Страница собрана по открытым каталогам, картам и архивным статьям. Неизвестное не выдумано.",
    },
    footer: {
      line: "Общеобразовательная средняя школа №194 · Ташкент, Учтепа",
      sources: "Источники и код",
      note: "Данные из открытых источников. Штат и численность не подтверждены.",
    },
  },
  en: {
    siteName: "School 194",
    kicker: "Tashkent · Uchtepa district",
    nav: {
      home: "Home",
      about: "School",
      history: "History",
      education: "Studies",
      people: "Teachers",
      contacts: "Contact",
      sources: "Sources",
    },
    hero: {
      eyebrow: "General secondary school",
      title: "School No. 194",
      lead: "A state school with Russian as the language of instruction on Chilanzar-25. The building is 1960s Tashkent modernism.",
      cta: "Address & phone",
      secondary: "School history",
    },
    facts: [
      { label: "Address", value: "Uchtepa, Chilanzar-25, 16a" },
      { label: "Phone", value: "+998 71 272-08-05" },
      { label: "Hours", value: "Mon–Sat 08:00–18:00" },
      { label: "Language", value: "Russian" },
    ],
    homeAbout: {
      kicker: "Today",
      title: "Uchtepa district, Chilanzar-25",
      body: "The school stands in Tashkent, Uchtepa district, Chilanzar-25 block, building 16a. Legal name: General Secondary School No. 194. Operator: Ministry of Preschool and School Education of Uzbekistan. Instruction is in Russian.",
      more: "About the school",
    },
    homeArch: {
      kicker: "Building",
      title: "TasHNIEP project, 1965",
      body: "A 1967 courtyard photograph survives. Architects B. P. Blum, N. P. Zinkina, T. V. Lemina; engineer L. E. Goritsky. The same series was built across Chilanzar and the republic.",
      more: "Architecture",
    },
    homePeople: {
      kicker: "Memory",
      title: "Teachers alumni still name",
      body: "No public staff roster. In comments on a 2022 school video, graduates thank specific teachers by name.",
      more: "Names",
    },
    about: {
      title: "About the school",
      lead: "A state general secondary school. Grades 1–11. Russian-medium.",
      cards: [
        {
          title: "Status",
          body: "Legal name: General Secondary School No. 194. A public institution under the Uchtepa district preschool and school education department.",
        },
        {
          title: "Place",
          body: "Tashkent, 100152, Uchtepa district, Chilanzar-25, 16a. Landmarks: Uchtepa Eco Park, kindergarten No. 360, post office No. 152. Directories also list Shibaeva street.",
        },
        {
          title: "Building",
          body: "Three storeys. OpenStreetMap: 41.28226° N, 69.16654° E. Plus code: 8JHF75J8+WJ.",
        },
        {
          title: "Name",
          body: "Russian maps still carry «School No. 194 named after Leningrad». The title likely remembers children evacuated from Leningrad to Tashkent in wartime.",
        },
      ],
      note: "Enrolment, the current director and the staff list are not confirmed in open sources — this site does not invent them.",
    },
    history: {
      title: "History & architecture",
      lead: "Chilanzar took shape in the 1950s–60s. School 194 belongs to that wave of housing and civic buildings.",
      timeline: [
        {
          year: "1950–63",
          title: "Chilanzar is laid out",
          body: "Multi-storey housing blocks go up. On 4 January 1963 Chilanzar becomes an official district. The 25th block later moved into Uchtepa district.",
        },
        {
          year: "1964–65",
          title: "School series 224-1-3S / 4S",
          body: "Architect Boris Isaakovich Blum (b. 25 August 1931, Tashkent), N. P. Zinkina, T. V. Lemina and engineer L. E. Goritsky design 3–4 storey schools for 960–1000 and 1280–1320 pupils. Blum received a USSR Union of Architects diploma in 1986.",
        },
        {
          year: "1966",
          title: "Earthquake and reconstruction",
          body: "After the 1966 earthquake Tashkent is rebuilt at metropolitan scale. Schools are planned into every microdistrict.",
        },
        {
          year: "1967",
          title: "Courtyard photograph",
          body: "N. D. Koveshnikov photographs school 194 from the yard. TasHNIEP project of 1965. Schools 17, 5 and others follow the same plan.",
        },
        {
          year: "Now",
          title: "Uchtepa, Chilanzar-25",
          body: "The school is open. Three floors. Russian-medium. Nearby: kindergarten 360, Uchtepa Eco Park, schools 287 and 78.",
        },
      ],
      archNote:
        "The type has a rhythmic classroom wing, sun-shading on the windows, and a yard with a sports court. School 107 on Chilanzar-26 is a full-height example; others were built lower, with a shorter gym.",
    },
    education: {
      title: "Studies",
      lead: "General secondary education: primary, basic and upper secondary. Language of instruction: Russian.",
      blocks: [
        {
          title: "Grades 1–4",
          body: "Primary school on Uzbekistan’s national curriculum. Russian-medium status is listed in Golden Pages and district directories.",
        },
        {
          title: "Grades 5–9",
          body: "Basic secondary education, state assessment, and the next step of study.",
        },
        {
          title: "Grades 10–11",
          body: "Complete secondary education. Graduates move on to universities, colleges or service.",
        },
      ],
      langTitle: "Russian-medium",
      langBody:
        "Uchtepa has both Uzbek- and Russian-medium schools side by side. 194 is one of the Russian ones. Nearby school 193 is listed as Uzbek-medium — families in the block have a choice.",
      hoursTitle: "Hours",
      hoursBody:
        "Directories: Monday–Saturday 08:00–18:00 with no lunch break; Sunday closed. Some maps show 08:30. Lesson timetables come from the school office.",
    },
    people: {
      title: "Teachers",
      lead: "Names taken from alumni comments on a 8 March 2022 video. This is memory, not a current roster.",
      disclaimer:
        "The director and full staff are not published in open sources. If a name is misspelled, send a correction.",
      source: "Source: YouTube channel «ШКОЛА-194 УЧТЕПА ГОРОД ТАШКЕНТ»",
    },
    contacts: {
      title: "Contact",
      lead: "Call the school. Reception hours are not listed in open sources.",
      addressLabel: "Address",
      address: "Uzbekistan, 100152, Tashkent, Uchtepa district, Chilanzar-25 block, 16a",
      phoneLabel: "Phone",
      hoursLabel: "Hours",
      hours: "Monday–Saturday: 08:00–18:00. Sunday: closed.",
      transitLabel: "Transport (directory)",
      transit: "Buses 2, 8, 41, 77; marshrutkas 14, 15, 21 — Top.uz. Routes may have changed.",
      nearbyLabel: "Landmarks",
      nearby: "Kindergarten No. 360 (≈130 m), Nur Saroy hall, Uchtepa Eco Park, post office 152, school 287.",
      mapLabel: "Map",
      call: "Call",
      osm: "OpenStreetMap",
      gmaps: "Google Maps",
      formTitle: "Leave a note",
      formLead: "This is not sent to the school — it stays in your browser. For official questions, call.",
      formName: "Name",
      formText: "Note",
      formSubmit: "Save",
      formEmpty: "No notes yet.",
    },
    sources: {
      title: "Sources",
      lead: "Compiled from public directories, maps and archive articles. Unknown facts are left blank, not invented.",
    },
    footer: {
      line: "General Secondary School No. 194 · Tashkent, Uchtepa",
      sources: "Sources & code",
      note: "Open-source facts only. Staff and enrolment are unverified.",
    },
  },
} as const;

export type Copy = (typeof copy)[Lang];
