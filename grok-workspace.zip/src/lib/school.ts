export const school = {
  number: "194",
  phoneDisplay: "+998 71 272-08-05",
  phoneTel: "+998712720805",
  postalCode: "100152",
  floors: 3,
  osmWay: "164886454",
  plusCode: "8JHF75J8+WJ",
  coords: { lat: 41.28226, lon: 69.16654 },
  youtube: "https://www.youtube.com/@%D0%A8%D0%9A%D0%9E%D0%9B%D0%90-194%D0%A3%D0%A7%D0%A2%D0%95%D0%9F%D0%90%D0%93%D0%9E%D0%A0%D0%9E%D0%94%D0%A2%D0%90%D0%A8%D0%9A%D0%95%D0%9D%D0%A2",
  youtubeSearch: "https://www.youtube.com/results?search_query=%D0%A8%D0%9A%D0%9E%D0%9B%D0%90-194+%D0%A3%D0%A7%D0%A2%D0%95%D0%9F%D0%90",
  osm: "https://www.openstreetmap.org/way/164886454",
  mapEmbed:
    "https://www.openstreetmap.org/export/embed.html?bbox=69.1605%2C41.2785%2C69.1725%2C41.2860&layer=mapnik&marker=41.28226%2C69.16654",
  googleMaps: "https://www.google.com/maps?q=41.28226,69.16654",
  goldenPages: "https://www.goldenpages.uz/en/company/?Id=46664",
  twoGis: "https://2gis.uz/tashkent/firm/70000001037921127",
  yellowPages: "https://www.yellowpages.uz/kompaniya/obscheobrazovatelnaya-srednyaya-shkola-194",
  mytashkent: "https://mytashkent.uz/2023/08/19/shkola-194-na-25-kvartale-chilanzara/",
  architectBlum: "https://mytashkent.uz/2017/09/10/arhitektor-boris-blyum/",
  hours: {
    weekdays: "08:00 – 18:00",
    sunday: "closed",
  },
} as const;

export const teachers = [
  { name: "Guzal Gayazovna", nameRu: "Гузаль Гаязовна", nameUz: "Guzal Gayazovna" },
  { name: "Roza Huramovna", nameRu: "Роза Хурамовна", nameUz: "Roza Xuramovna", note: "3V" },
  { name: "Filyura Raufovna", nameRu: "Филюра Рауфовна", nameUz: "Filyura Raufovna" },
  { name: "Saida Alidzhanovna", nameRu: "Саида Алиджановна", nameUz: "Saida Alidjanovna" },
  { name: "Olesya Valeryevna", nameRu: "Олеся Валерьевна", nameUz: "Olesya Valeryevna" },
  { name: "Aida Vladimirovna", nameRu: "Аида Владимировна", nameUz: "Aida Vladimirovna" },
  { name: "Gulnoza Bahadyrovna", nameRu: "Гульноза Бахадыровна", nameUz: "Gulnoza Bahadirovna" },
  { name: "Yulia Anatolyevna", nameRu: "Юлия Анатольевна", nameUz: "Yuliya Anatolyevna" },
  { name: "Svetlana Vladimirovna", nameRu: "Светлана Владимировна", nameUz: "Svetlana Vladimirovna" },
] as const;

export const sources = [
  {
    title: "Golden Pages Uzbekistan — School #194",
    url: "https://www.goldenpages.uz/en/company/?Id=46664",
    about: "Address, phone 71 2720805, hours, Russian instruction, Chilanzar-25",
  },
  {
    title: "2GIS — Общеобразовательная средняя школа №194",
    url: "https://2gis.uz/tashkent/firm/70000001037921127",
    about: "Uchtepa 25-mavze, 16a; 3 floors; postal 100152",
  },
  {
    title: "Yellow Pages Uzbekistan",
    url: "https://www.yellowpages.uz/kompaniya/obscheobrazovatelnaya-srednyaya-shkola-194",
    about: "Legal name, ECOPARK landmark, Shibaeva street",
  },
  {
    title: "OpenStreetMap way 164886454",
    url: "https://www.openstreetmap.org/way/164886454",
    about: "Coordinates, operator, Russian name «им. Ленинграда»",
  },
  {
    title: "Письма о Ташкенте — школа №194, фото 1967",
    url: "https://mytashkent.uz/2023/08/19/shkola-194-na-25-kvartale-chilanzara/",
    about: "TasHNIEP 1965 project, architects, courtyard photo by N. D. Koveshnikov",
  },
  {
    title: "Письма о Ташкенте — архитектор Борис Блюм",
    url: "https://mytashkent.uz/2017/09/10/arhitektor-boris-blyum/",
    about: "Series 224-1-3S / 224-1-4S, 960–1320 pupils, 1964–65",
  },
  {
    title: "Top.uz directory",
    url: "https://top.uz/company/srednyaya-shkola-194",
    about: "Hours, buses 2, 8, 41, 77; marshrut 14, 15, 21",
  },
  {
    title: "YouTube — ШКОЛА-194 УЧТЕПА ГОРОД ТАШКЕНТ",
    url: "https://www.youtube.com/watch?v=qX2CU_hhn2U",
    about: "Alumni comments naming teachers, March 8 2022",
  },
] as const;
