import { createFileRoute } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { useI18n } from "@/lib/i18n";
import { school } from "@/lib/school";

export const Route = createFileRoute("/about")({ component: AboutPage });

function AboutPage() {
  const { t } = useI18n();

  return (
    <div>
      <PageHead kicker={t.kicker} title={t.about.title} lead={t.about.lead} />
      <div className="mx-auto grid max-w-6xl gap-4 px-4 pb-16 sm:px-6 md:grid-cols-2">
        {t.about.cards.map((card) => (
          <article key={card.title} className="rounded-lg border border-border bg-bg-elevated p-6">
            <h2 className="text-2xl">{card.title}</h2>
            <p className="mt-3 text-fg-muted">{card.body}</p>
          </article>
        ))}
      </div>
      <aside className="mx-auto max-w-6xl px-4 pb-8 sm:px-6">
        <p className="rounded-md border border-border bg-bg-elevated px-5 py-4 text-sm text-fg-muted">
          {t.about.note}
        </p>
        <p className="mt-4 text-xs text-fg-subtle">
          OSM {school.osmWay} · {school.plusCode} · {school.coords.lat}, {school.coords.lon}
        </p>
      </aside>
      <div className="mx-auto max-w-6xl px-4 pb-16 sm:px-6">
        <img src="/images/facade.jpg" alt="" className="aspect-[21/9] w-full rounded-xl object-cover" />
      </div>
    </div>
  );
}
