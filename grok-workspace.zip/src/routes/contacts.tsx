import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { PageHead } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { useI18n } from "@/lib/i18n";
import { school } from "@/lib/school";

export const Route = createFileRoute("/contacts")({ component: ContactsPage });

type Note = { id: string; name: string; text: string; at: number };
const NOTES_KEY = "maktab194-notes";

function ContactsPage() {
  const { t } = useI18n();
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [notes, setNotes] = useState<Note[]>([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(NOTES_KEY);
      if (raw) setNotes(JSON.parse(raw) as Note[]);
    } catch {
      /* ignore */
    }
  }, []);

  const save = (event: FormEvent) => {
    event.preventDefault();
    if (!text.trim()) return;
    const next = [
      { id: crypto.randomUUID(), name: name.trim() || "—", text: text.trim(), at: Date.now() },
      ...notes,
    ].slice(0, 20);
    setNotes(next);
    localStorage.setItem(NOTES_KEY, JSON.stringify(next));
    setText("");
  };

  return (
    <div>
      <PageHead kicker={t.kicker} title={t.contacts.title} lead={t.contacts.lead} />
      <div className="mx-auto grid max-w-6xl gap-10 px-4 pb-16 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]">
        <dl className="space-y-6">
          <div>
            <dt className="text-xs uppercase tracking-[0.16em] text-fg-muted">{t.contacts.addressLabel}</dt>
            <dd className="mt-2 text-lg">{t.contacts.address}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-[0.16em] text-fg-muted">{t.contacts.phoneLabel}</dt>
            <dd className="mt-2">
              <a href={`tel:${school.phoneTel}`} className="font-display text-2xl no-underline">
                {school.phoneDisplay}
              </a>
            </dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-[0.16em] text-fg-muted">{t.contacts.hoursLabel}</dt>
            <dd className="mt-2 text-fg-muted">{t.contacts.hours}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-[0.16em] text-fg-muted">{t.contacts.transitLabel}</dt>
            <dd className="mt-2 text-fg-muted">{t.contacts.transit}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-[0.16em] text-fg-muted">{t.contacts.nearbyLabel}</dt>
            <dd className="mt-2 text-fg-muted">{t.contacts.nearby}</dd>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button asChild variant="ink">
              <a href={`tel:${school.phoneTel}`}>{t.contacts.call}</a>
            </Button>
            <Button asChild variant="outline">
              <a href={school.osm} target="_blank" rel="noreferrer">
                {t.contacts.osm}
              </a>
            </Button>
            <Button asChild variant="outline">
              <a href={school.googleMaps} target="_blank" rel="noreferrer">
                {t.contacts.gmaps}
              </a>
            </Button>
          </div>
        </dl>

        <div>
          <p className="mb-3 text-xs uppercase tracking-[0.16em] text-fg-muted">{t.contacts.mapLabel}</p>
          <iframe
            title={t.contacts.mapLabel}
            src={school.mapEmbed}
            className="h-80 w-full rounded-lg border border-border bg-bg-elevated"
            loading="lazy"
          />
        </div>
      </div>

      <section className="border-t border-border bg-bg-elevated">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-2">
          <form onSubmit={save} className="space-y-4">
            <h2 className="text-3xl">{t.contacts.formTitle}</h2>
            <p className="text-sm text-fg-muted">{t.contacts.formLead}</p>
            <label className="block text-sm">
              <span className="mb-1.5 block text-fg-muted">{t.contacts.formName}</span>
              <Input value={name} onChange={(e) => setName(e.target.value)} />
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-fg-muted">{t.contacts.formText}</span>
              <Textarea value={text} onChange={(e) => setText(e.target.value)} required />
            </label>
            <Button type="submit" variant="ink">
              {t.contacts.formSubmit}
            </Button>
          </form>
          <ul className="space-y-3">
            {notes.length === 0 ? (
              <li className="text-sm text-fg-muted">{t.contacts.formEmpty}</li>
            ) : (
              notes.map((note) => (
                <li key={note.id} className="rounded-md border border-border bg-bg p-4">
                  <p className="text-xs uppercase tracking-[0.14em] text-fg-muted">{note.name}</p>
                  <p className="mt-2 text-sm">{note.text}</p>
                </li>
              ))
            )}
          </ul>
        </div>
      </section>
    </div>
  );
}
