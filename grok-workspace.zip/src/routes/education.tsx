import { createFileRoute } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/education")({ component: EducationPage });

function EducationPage() {
  const { t } = useI18n();

  return (
    <div>
      <PageHead kicker={t.kicker} title={t.education.title} lead={t.education.lead} />
      <div className="mx-auto grid max-w-6xl gap-4 px-4 sm:px-6 md:grid-cols-3">
        {t.education.blocks.map((block) => (
          <article key={block.title} className="rounded-lg border border-border bg-bg-elevated p-6">
            <h2 className="text-2xl">{block.title}</h2>
            <p className="mt-3 text-fg-muted">{block.body}</p>
          </article>
        ))}
      </div>
      <div className="mx-auto mt-10 grid max-w-6xl gap-6 px-4 pb-16 sm:px-6 lg:grid-cols-2">
        <section className="rounded-lg bg-bg-ink p-6 text-fg-on-ink">
          <h2 className="text-2xl">{t.education.langTitle}</h2>
          <p className="mt-3 text-fg-on-ink/75">{t.education.langBody}</p>
        </section>
        <section className="rounded-lg border border-border bg-bg-elevated p-6">
          <h2 className="text-2xl">{t.education.hoursTitle}</h2>
          <p className="mt-3 text-fg-muted">{t.education.hoursBody}</p>
        </section>
      </div>
      <div className="mx-auto max-w-6xl px-4 pb-16 sm:px-6">
        <img src="/images/classroom.jpg" alt="" className="aspect-[16/8] w-full rounded-xl object-cover" />
      </div>
    </div>
  );
}
