import { createFileRoute } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/history")({ component: HistoryPage });

function HistoryPage() {
  const { t } = useI18n();

  return (
    <div>
      <PageHead kicker={t.kicker} title={t.history.title} lead={t.history.lead} />
      <div className="mx-auto grid max-w-6xl gap-10 px-4 pb-8 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]">
        <img src="/images/hero.jpg" alt="" className="aspect-[4/5] w-full rounded-xl object-cover" />
        <ol className="space-y-8">
          {t.history.timeline.map((item) => (
            <li key={item.year} className="grid gap-2 border-l border-border pl-5 sm:grid-cols-[7rem_1fr] sm:border-0 sm:pl-0">
              <p className="font-mono text-xs uppercase tracking-[0.16em] text-sage">{item.year}</p>
              <div>
                <h2 className="text-2xl">{item.title}</h2>
                <p className="mt-2 text-fg-muted">{item.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
      <p className="mx-auto max-w-6xl px-4 pb-16 text-sm text-fg-muted sm:px-6">{t.history.archNote}</p>
    </div>
  );
}
