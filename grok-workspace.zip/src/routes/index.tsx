import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { school } from "@/lib/school";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { t } = useI18n();

  return (
    <div>
      <section className="relative overflow-hidden border-b border-border">
        <div className="mx-auto grid max-w-6xl items-end gap-10 px-4 pb-12 pt-10 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:pt-16">
          <div>
            <p className="text-xs uppercase tracking-[0.22em] text-fg-muted">{t.hero.eyebrow}</p>
            <h1 className="mt-4 max-w-xl text-5xl sm:text-6xl lg:text-7xl">{t.hero.title}</h1>
            <p className="mt-2 text-sm uppercase tracking-[0.18em] text-sage">{t.kicker}</p>
            <p className="mt-6 max-w-lg text-lg text-fg-muted">{t.hero.lead}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="ink">
                <Link to="/contacts">{t.hero.cta}</Link>
              </Button>
              <Button asChild variant="outline">
                <Link to="/history">{t.hero.secondary}</Link>
              </Button>
            </div>
          </div>
          <figure className="overflow-hidden rounded-xl shadow-soft">
            <img
              src="/images/hero.jpg"
              alt=""
              className="aspect-[16/10] h-full w-full object-cover"
            />
            <figcaption className="bg-bg-ink px-4 py-3 text-xs text-fg-on-ink/70">
              Chilanzar-25 · TasHNIEP 1965
            </figcaption>
          </figure>
        </div>
      </section>

      <section className="border-b border-border bg-bg-elevated">
        <dl className="mx-auto grid max-w-6xl grid-cols-2 gap-px sm:grid-cols-4">
          {t.facts.map((fact) => (
            <div key={fact.label} className="px-4 py-7 sm:px-6">
              <dt className="text-xs uppercase tracking-[0.16em] text-fg-muted">{fact.label}</dt>
              <dd className="mt-2 font-display text-xl">{fact.value}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:items-center">
        <div>
          <p className="text-xs uppercase tracking-[0.22em] text-fg-muted">{t.homeAbout.kicker}</p>
          <h2 className="mt-3 text-3xl sm:text-4xl">{t.homeAbout.title}</h2>
          <p className="mt-4 text-fg-muted">{t.homeAbout.body}</p>
          <Link
            to="/about"
            className="mt-6 inline-flex min-h-11 items-center gap-2 text-sm font-medium no-underline"
          >
            {t.homeAbout.more}
            <ArrowRight size={16} />
          </Link>
        </div>
        <img src="/images/park.jpg" alt="" className="aspect-[16/10] w-full rounded-lg object-cover" />
      </section>

      <section className="bg-bg-ink text-fg-on-ink">
        <div className="mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:items-center">
          <img
            src="/images/classroom.jpg"
            alt=""
            className="order-2 aspect-[16/10] w-full rounded-lg object-cover lg:order-1"
          />
          <div className="order-1 lg:order-2">
            <p className="text-xs uppercase tracking-[0.22em] text-fg-on-ink/55">{t.homeArch.kicker}</p>
            <h2 className="mt-3 text-3xl sm:text-4xl">{t.homeArch.title}</h2>
            <p className="mt-4 text-fg-on-ink/75">{t.homeArch.body}</p>
            <Link
              to="/history"
              className="mt-6 inline-flex min-h-11 items-center gap-2 text-sm font-medium no-underline"
            >
              {t.homeArch.more}
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_0.8fr] lg:items-center">
        <div>
          <p className="text-xs uppercase tracking-[0.22em] text-fg-muted">{t.homePeople.kicker}</p>
          <h2 className="mt-3 text-3xl sm:text-4xl">{t.homePeople.title}</h2>
          <p className="mt-4 text-fg-muted">{t.homePeople.body}</p>
          <Link
            to="/people"
            className="mt-6 inline-flex min-h-11 items-center gap-2 text-sm font-medium no-underline"
          >
            {t.homePeople.more}
            <ArrowRight size={16} />
          </Link>
        </div>
        <img src="/images/desk.jpg" alt="" className="aspect-[4/3] w-full rounded-lg object-cover" />
      </section>

      <section className="border-t border-border bg-bg-elevated">
        <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-12 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div>
            <p className="font-display text-3xl">{school.phoneDisplay}</p>
            <p className="mt-1 text-sm text-fg-muted">{t.contacts.address}</p>
          </div>
          <Button asChild variant="ink">
            <a href={`tel:${school.phoneTel}`}>{t.contacts.call}</a>
          </Button>
        </div>
      </section>
    </div>
  );
}
