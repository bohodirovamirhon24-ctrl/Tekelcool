import { createFileRoute } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { useI18n } from "@/lib/i18n";
import { school, teachers } from "@/lib/school";

export const Route = createFileRoute("/people")({ component: PeoplePage });

function PeoplePage() {
  const { t, lang } = useI18n();

  return (
    <div>
      <PageHead kicker={t.kicker} title={t.people.title} lead={t.people.lead} />
      <div className="mx-auto max-w-3xl px-4 pb-6 sm:px-6">
        <p className="rounded-md border border-border bg-bg-elevated px-5 py-4 text-sm text-fg-muted">
          {t.people.disclaimer}
        </p>
      </div>
      <ul className="mx-auto max-w-3xl divide-y divide-border border-y border-border">
        {teachers.map((teacher) => (
          <li key={teacher.nameRu} className="flex items-baseline justify-between gap-4 px-4 py-4 sm:px-6">
            <span className="font-display text-xl">
              {lang === "ru" ? teacher.nameRu : lang === "uz" ? teacher.nameUz : teacher.name}
            </span>
            {"note" in teacher && teacher.note ? (
              <span className="font-mono text-xs uppercase tracking-[0.14em] text-fg-muted">{teacher.note}</span>
            ) : null}
          </li>
        ))}
      </ul>
      <p className="mx-auto max-w-3xl px-4 py-10 text-sm text-fg-muted sm:px-6">
        <a href={school.youtubeSearch} className="underline-offset-4 hover:underline">
          {t.people.source}
        </a>
      </p>
    </div>
  );
}
