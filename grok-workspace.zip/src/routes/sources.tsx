import { createFileRoute } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { useI18n } from "@/lib/i18n";
import { sources } from "@/lib/school";

export const Route = createFileRoute("/sources")({ component: SourcesPage });

function SourcesPage() {
  const { t } = useI18n();

  return (
    <div>
      <PageHead kicker={t.kicker} title={t.sources.title} lead={t.sources.lead} />
      <p className="mx-auto max-w-3xl px-4 pb-8 text-sm sm:px-6">
        <a href="/SCHOOL-194.md" className="underline-offset-4 hover:underline" download>
          SCHOOL-194.md
        </a>
      </p>
      <ol className="mx-auto max-w-3xl space-y-6 px-4 pb-16 sm:px-6">
        {sources.map((source, index) => (
          <li key={source.url} className="border-t border-border pt-5">
            <p className="font-mono text-xs text-fg-muted">{String(index + 1).padStart(2, "0")}</p>
            <a href={source.url} className="mt-1 block font-display text-2xl no-underline hover:underline" target="_blank" rel="noreferrer">
              {source.title}
            </a>
            <p className="mt-2 text-sm text-fg-muted">{source.about}</p>
          </li>
        ))}
      </ol>
    </div>
  );
}
